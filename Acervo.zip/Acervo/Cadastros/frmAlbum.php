<html>
    <form action="../cadastrar.php"></form>
</html>