<?php 
$conexao = mysqli_connect("localhost", "Aluno2DS", "SenhaBD2", "ACERVO");
