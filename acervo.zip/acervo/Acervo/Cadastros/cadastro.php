<?php
    echo "teste";
?>