<?php
    session_start();
    $conexao = mysqli_connect("localhost","Aluno2DS","SenhaBD2","ACERVO");
    $_SESSION['form'] = "Musica";
    ?>   

<html>
    <body>
        <head>
        <link rel="stylesheet" href="frmMusica.css">
        </head>
        <form action="cadastrar.php">
            <div>
                <label>Nome da música</label>
                <input placeholder="Nome da música"><br/>
                <label>Duração</label>
                <input placeholder="HH/MM/SS"><br/>
                <label for="txbgenero">Genero</label><select name="txbgenero">
                <?php
                $sql = "SELECT GNRCODIGO, GNRNOME FROM GENEROS";
                $consulta = mysqli_query($conexao, $sql);
                while($vReg = mysqli_fetch_assoc($consulta)){
                echo"<option value='". $vReg["GNRCODIGO"] ."'>". $vReg["GNRNOME"] ."</option>";
                }
                ?>   
                </select><br>
                <label for="txbgenero">Banda</label><select name="txbgenero">
                <?php
                $sql = "SELECT GNRCODIGO, GNRNOME FROM GENEROS";
                $consulta = mysqli_query($conexao, $sql);
                while($vReg = mysqli_fetch_assoc($consulta)){
                echo"<option value='". $vReg["GNRCODIGO"] ."'>". $vReg["GNRNOME"] ."</option>";
                }
                ?>   
                </select><br>
                <label for="txbgenero">Artista</label><select name="txbgenero">
                <?php
                $sql = "SELECT GNRCODIGO, GNRNOME FROM GENEROS";
                $consulta = mysqli_query($conexao, $sql);
                while($vReg = mysqli_fetch_assoc($consulta)){
                echo"<option value='". $vReg["GNRCODIGO"] ."'>". $vReg["GNRNOME"] ."</option>";
                }
                ?>   
                </select><br>
                <label>Letra</label>
                <textarea></textarea>
            </div>
        </form>
    </body>
</html>