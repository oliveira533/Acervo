<?php
    session_start();
    $oForm = $_SESSION['form'];

    $oCon = mysqli_connect("localhost","Aluno2DS","SenhaBD2","ACERVO");
    $oQuerry;

    if($oForm == "Genero"){
        $oGenNome = $_GET['txbNome'];
        $oGenDesc = $_GET['txadesc'];
        $oQuerry = "INSERT INTO GENEROS (GNRNOME, GNRDESCRICAO) VALUES ('".$oGenNome."', '".$oGenDesc."')";
        mysqli_query($oCon ,$oQuerry);
        var_dump($oCon);
    }
?>





