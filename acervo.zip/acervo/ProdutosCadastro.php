<?php 
    $conexao = mysqli_connect("localhost","Aluno2DS", "SenhaBD2", "BANCOCOMUM");
    $sTitulo = $_GET["txbTitulo"];
    $sSubTit = $_GET["txbSubTit"];
    $sDescricao = $_GET["txaDescricao"];
    $nValor = $_GET["txbValor"];
    $sql = "INSERT INTO PRODUTOS (PRDTITULO, PRDSUBTITULO, PRDDESCRICAO, PRDVALOR) VALUES ('$sTitulo', '$sSubTit', '$sDescricao', $nValor);";
    mysqli_query($conexao, $sql);
    mysqli_close($conexao);
    header("location: ProdutosCadastro.htm")
?>