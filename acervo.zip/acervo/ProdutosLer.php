<html>
<style>
    *{
        font-size: 24px;  
    }
</style>
<?php
    $conexao = mysqli_connect("localhost","Aluno2DS", "SenhaBD2", "BANCOCOMUM");//Se conecta ao servidor
    $sql = "SELECT * FROM PRODUTOS";//Consulta Sql
    $resultado = mysqli_query($conexao, $sql);//Ele armazena o resultado da consulta nesta variavel
    while($registro = mysqli_fetch_array($resultado)){ //Ele traz uma array com os dados da consulta, se não ouver dados ele traz false
        echo $registro['PRDTITULO'].'<br />';//Ele traz a parte da array com o nome PDRTITULO
    }
    mysqli_free_result($resultado);//Libera o espaço da memoria
    mysqli_close($conexao);//Fecha Conexão
    ?>
</html>